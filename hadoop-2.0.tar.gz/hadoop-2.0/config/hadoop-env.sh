
# Overwrite location of the log directory
export HADOOP_LOG_DIR=/local_scratch/lngo/hadoop/log
